package com.apd.tema2.strategy;

import com.apd.tema2.entities.Car;

public interface ExerciseStrategy {
    void runExercise(Car car);
}
